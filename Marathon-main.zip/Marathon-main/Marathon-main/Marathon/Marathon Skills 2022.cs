﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Marathon_Selin
{
    public partial class Marathon_Skills_2022 : Form
    {
        public Marathon_Skills_2022()
        {
            InitializeComponent();
        }
    }
}
